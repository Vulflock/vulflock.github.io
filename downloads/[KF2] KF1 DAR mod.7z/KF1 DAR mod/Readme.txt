To install extract the "BrewedPC" folder into
"C:\Users\*Your Username*\Documents\My Games\KillingFloor2\KFGame\Published"
If the folder "Published" doesn't exist, make a new folder and name it "Published".

To uninstall, delete the "Windows" folder from
"C:\Users\*Your Username*\Documents\My Games\KillingFloor2\KFGame\Published\BrewedPC\WwiseAudio\Windows".

Note: This will also delete all other mods using this folder (Character voices, the traders voice and music.)
If you have other mods using this folder I suggest simply re-installing them as thats way simpler and easier than picking out this mods files.

Another Note: Yes, DARs voice files are not actually located in the English(US) folder.
Instead, DARs voice files are located in the same folder as music and sound effects.

~~~~~~~~~~~~~~~~~~~~~~

Alternatively, you can overwrite the actual in-game files of the trader.
Only use this method if the previous one doesn't work or if you want to save space on your "C:\" drive.
(There's no reason it shouldn't have worked. Try Method #1 again before continueing with Method #2)
(You will only save <10MB)

To install using the alternative method extract the "BrewedPC" folder into
"C:\Program Files (x86)\Steam\steamapps\common\killingfloor2" or wherever you have Killing Floor 2 installed.

I recommend making a backup of the entire "WwiseAudio" folder, unless you want to pick out traders voice files yourself.

To uninstall validate your files using steam or use your backup.

